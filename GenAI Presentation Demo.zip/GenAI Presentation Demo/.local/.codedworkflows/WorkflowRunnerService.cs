using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UiPath.CodedWorkflows;
using UiPath.CodedWorkflows.Interfaces;
using UiPath.Activities.Contracts;
using GenAIDemo;

[assembly: WorkflowRunnerServiceAttribute(typeof(GenAIDemo.WorkflowRunnerService))]
namespace GenAIDemo
{
    public class WorkflowRunnerService
    {
        private readonly ICodedWorkflowServices _services;
        public WorkflowRunnerService(ICodedWorkflowServices services)
        {
            _services = services;
        }

        /// <summary>
        /// Invokes the Summarize Text.xaml
        /// </summary>
        public void Summarize_Text()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Summarize Text.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the GenAI Demo/Translate.xaml
        /// </summary>
        public void GenAI_Demo_Translate()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"GenAI Demo\Translate.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the GenAI Demo/Workflow.xaml
        /// </summary>
        public void Workflow()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"GenAI Demo\Workflow.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the GenAI Demo/Content Generation.xaml
        /// </summary>
        public void GenAI_Demo_Content_Generation()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"GenAI Demo\Content Generation.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the GenAI Demo/Rewrite.xaml
        /// </summary>
        public void GenAI_Demo_Rewrite()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"GenAI Demo\Rewrite.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Translate.xaml
        /// </summary>
        public void Translate()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Translate.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the GenAI Demo/Summarize Text.xaml
        /// </summary>
        public void GenAI_Demo_Summarize_Text()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"GenAI Demo\Summarize Text.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the GenAI Demo/Main.xaml
        /// </summary>
        public void GenAI_Demo_Main()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"GenAI Demo\Main.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the GenAI Demo/Generate Email.xaml
        /// </summary>
        public void GenAI_Demo_Generate_Email()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"GenAI Demo\Generate Email.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Rewrite.xaml
        /// </summary>
        public void Rewrite()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Rewrite.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Context Grounding.cs
        /// </summary>
        public void Context_Grounding()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Context Grounding.cs", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the GenAI Demo/Language Detection.xaml
        /// </summary>
        public void GenAI_Demo_Language_Detection()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"GenAI Demo\Language Detection.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Semantic Similarity.xaml
        /// </summary>
        public void Semantic_Similarity()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Semantic Similarity.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the PII Filtering.xaml
        /// </summary>
        public void PII_Filtering()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"PII Filtering.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Main.xaml
        /// </summary>
        public void Main()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Main.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Language Detection.xaml
        /// </summary>
        public void Language_Detection()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Language Detection.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Image Analysis.xaml
        /// </summary>
        public void Image_Analysis()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Image Analysis.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Detect Object.xaml
        /// </summary>
        public void Detect_Object()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Detect Object.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Content Generation.xaml
        /// </summary>
        public void Content_Generation()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Content Generation.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the GenAI Demo/PII Filtering.xaml
        /// </summary>
        public void GenAI_Demo_PII_Filtering()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"GenAI Demo\PII Filtering.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Signature Similarity.xaml
        /// </summary>
        public void Signature_Similarity()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Signature Similarity.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Reformat Demo.xaml
        /// </summary>
        public void Reformat_Demo()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Reformat Demo.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Named Entity Recognition.xaml
        /// </summary>
        public void Named_Entity_Recognition()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Named Entity Recognition.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Image Comparison.xaml
        /// </summary>
        public void Image_Comparison()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Image Comparison.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Generate Email.xaml
        /// </summary>
        public void Generate_Email()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Generate Email.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Categorize Demo.xaml
        /// </summary>
        public void Categorize_Demo()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Categorize Demo.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        private string GetAssemblyName()
        {
            var assemblyProvider = _services.Container.Resolve<ILibraryAssemblyProvider>();
            return assemblyProvider.GetLibraryAssemblyName(GetType().Assembly);
        }
    }
}