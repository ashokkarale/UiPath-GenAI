using UiPath.CodedWorkflows;
using System;

namespace GenAIDemo
{
    public class ConnectionsManager
    {
        public ConnectionsManager(ICodedWorkflowsServiceContainer resolver)
        {
        }
    }
}